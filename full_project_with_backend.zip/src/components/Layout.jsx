import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, DownloadCloud } from 'lucide-react';
import { cn } from '@/lib/utils';

const navLinks = [
  { to: '/', text: 'Home' },
  { to: '/blog', text: 'Blog' },
  { to: '/youtube-downloader', text: 'YouTube' },
  { to: '/facebook-downloader', text: 'Facebook' },
  { to: '/terabox-downloader', text: 'TeraBox' },
];

const Layout = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-900 text-white font-sans flex flex-col">
      <header className="sticky top-0 z-50 bg-gray-900/80 backdrop-blur-lg border-b border-gray-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <Link to="/" className="flex items-center gap-2 text-2xl font-bold text-red-500">
              <DownloadCloud className="w-8 h-8" />
              <span>VidDownloader</span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              {navLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  className={({ isActive }) =>
                    cn(
                      'text-lg font-medium transition-colors hover:text-red-500',
                      isActive ? 'text-red-500' : 'text-gray-300'
                    )
                  }
                >
                  {link.text}
                </NavLink>
              ))}
            </nav>
            <div className="md:hidden">
              <button onClick={() => setIsMenuOpen(true)} className="text-gray-300 hover:text-white">
                <Menu className="w-7 h-7" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="fixed inset-0 z-50 bg-gray-900 p-6 md:hidden"
          >
            <div className="flex justify-between items-center mb-10">
              <Link to="/" className="flex items-center gap-2 text-2xl font-bold text-red-500" onClick={() => setIsMenuOpen(false)}>
                <DownloadCloud className="w-8 h-8" />
                <span>VidDownloader</span>
              </Link>
              <button onClick={() => setIsMenuOpen(false)} className="text-gray-300 hover:text-white">
                <X className="w-8 h-8" />
              </button>
            </div>
            <nav className="flex flex-col space-y-6">
              {navLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  onClick={() => setIsMenuOpen(false)}
                  className={({ isActive }) =>
                    cn(
                      'text-2xl font-semibold text-center py-2 rounded-md transition-colors hover:bg-gray-800',
                      isActive ? 'text-red-500 bg-gray-800' : 'text-white'
                    )
                  }
                >
                  {link.text}
                </NavLink>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
      
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {children}
      </main>

      <footer className="bg-gray-800/50 border-t border-gray-800 mt-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-6 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} VidDownloader. All Rights Reserved.</p>
          <p className="text-sm mt-2">A free tool to download and convert videos online.</p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;