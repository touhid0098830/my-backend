import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clipboard, Search, Download, Video, Music, Loader2, XCircle, Clock, HardDrive, Film, ServerCrash } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';

const VideoDownloader = ({ toolConfig }) => {
  const { placeholder, supportedDomains, title } = toolConfig;
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [videoInfo, setVideoInfo] = useState(null);
  const [error, setError] = useState(null);
  const { toast } = useToast();

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text);
      toast({
        title: "Pasted from clipboard!",
        description: "URL has been pasted into the input field.",
      });
    } catch (err) {
      toast({
        title: "Failed to paste",
        description: "Could not read from clipboard. Please paste manually.",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError(null);
    setVideoInfo(null);

    if (!url.trim()) {
      setError("Please paste a valid video link.");
      return;
    }

    if (supportedDomains && !supportedDomains.some(domain => url.toLowerCase().includes(domain))) {
        setError(`Unsupported link. Please use a ${title} link.`);
        return;
    }

    setIsLoading(true);

    // Simulate backend call and show placeholder functionality
    setTimeout(() => {
        setIsLoading(false);
        setError("This is a frontend demonstration. The backend for processing video links is not yet implemented. You can request this functionality in your next prompt! 🚀");
        toast({
            title: "🚧 Backend Not Implemented",
            description: "Video processing is currently disabled. This is a UI demo.",
            variant: "destructive",
            duration: 8000
        });

        // Keep this for UI demonstration purposes if needed in the future
        // setVideoInfo({
        //   title: "Awesome Demo Video File.mp4",
        //   duration: "12:34",
        //   size: "256 MB",
        //   thumbnail: "https://images.unsplash.com/photo-1528825871115-3581a5387919?w=500&h=300&fit=crop",
        //   streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
        // });
        // toast({
        //   title: "Video found!",
        //   description: "Ready to stream or download.",
        // });
    }, 1500);
  };

  const handleDownload = (format) => {
    toast({
      title: `Downloading ${format}`,
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const downloadOptions = [
    { format: '1080p', quality: 'Full HD', icon: Video },
    { format: '720p', quality: 'HD', icon: Video },
    { format: '360p', quality: 'SD', icon: Video },
    { format: 'MP3', quality: 'Audio', icon: Music },
  ];

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card className="bg-gray-800 border-gray-700 shadow-2xl shadow-red-500/10">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit}>
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-grow">
                  <Input
                    type="text"
                    placeholder={placeholder}
                    className="h-14 pl-4 pr-12 text-lg bg-gray-900 border-gray-600 focus:ring-red-500 focus:border-red-500"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    disabled={isLoading}
                  />
                  <Button type="button" size="icon" variant="ghost" className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white" onClick={handlePaste} disabled={isLoading}>
                    <Clipboard className="w-6 h-6" />
                  </Button>
                </div>
                <Button type="submit" size="lg" className="h-14 text-lg bg-red-600 hover:bg-red-700" disabled={isLoading}>
                  {isLoading ? (
                    <Loader2 className="w-6 h-6 animate-spin" />
                  ) : (
                    <Search className="w-6 h-6" />
                  )}
                  <span className="ml-2">{isLoading ? 'Searching...' : 'Search'}</span>
                </Button>
              </div>
            </form>
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 text-center p-4 bg-yellow-900/30 border border-yellow-700 rounded-lg"
              >
                <div className="flex justify-center items-center gap-3">
                    <ServerCrash className="w-8 h-8 text-yellow-400" />
                    <p className="text-yellow-300 font-medium">{error}</p>
                </div>
              </motion.div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      <AnimatePresence>
        {videoInfo && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }}
            transition={{ duration: 0.6, type: 'spring' }}
            className="mt-10"
          >
            <Card className="bg-gray-800 border-gray-700 overflow-hidden">
              <CardContent className="p-0">
                <div className="aspect-video bg-black">
                   <video
                    key={videoInfo.streamUrl}
                    className="w-full h-full"
                    controls
                    poster={videoInfo.thumbnail}
                  >
                    <source src={videoInfo.streamUrl} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                </div>
                <div className="p-6">
                  <h2 className="text-2xl font-bold mb-3 flex items-center gap-2">
                    <Film className="w-7 h-7 text-red-400" />
                    {videoInfo.title}
                  </h2>
                  <div className="flex items-center gap-4 text-gray-400 mb-6">
                    <span className="flex items-center gap-2"><Clock className="w-5 h-5" /> {videoInfo.duration}</span>
                    <span className="flex items-center gap-2"><HardDrive className="w-5 h-5" /> {videoInfo.size}</span>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {downloadOptions.map((opt) => {
                      const Icon = opt.icon;
                      return (
                        <Button key={opt.format} variant="outline" className="h-16 flex-col gap-1 border-gray-600 hover:bg-gray-700 hover:text-white" onClick={() => handleDownload(opt.format)}>
                          <div className="flex items-center gap-2">
                            <Download className="w-5 h-5" />
                            <span className="text-lg font-semibold">{opt.format}</span>
                          </div>
                          <span className="text-xs text-gray-400">{opt.quality}</span>
                        </Button>
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default VideoDownloader;