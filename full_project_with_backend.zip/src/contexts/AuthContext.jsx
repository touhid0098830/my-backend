import React, { createContext, useState, useEffect } from 'react';
import apiClient from '../lib/apiClient';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  const login = async (email, password) => {
    const res = await apiClient.post('/login', { email, password });
    localStorage.setItem('token', res.token);
    setUser(res);
  };

  const register = async (email, password) => {
    const res = await apiClient.post('/register', { email, password });
    localStorage.setItem('token', res.token);
    setUser(res);
  };

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  const getProfile = async () => {
    const res = await apiClient.get('/profile');
    setUser(res);
  };

  useEffect(() => {
    if (localStorage.getItem('token')) {
      getProfile();
    }
  }, []);

  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};