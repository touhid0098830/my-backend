import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import blogPosts from '@/data/blogPosts.json';

const Blog = () => {
  return (
    <>
      <Helmet>
        <title>Video Downloader Tips & News | Our Blog</title>
        <meta name="description" content="Read the latest guides, video downloading tips, platform updates, and tool tutorials on our official blog." />
        <meta property="og:title" content="Video Downloader Tips & News | Our Blog" />
        <meta property="og:description" content="Read the latest guides, video downloading tips, platform updates, and tool tutorials on our official blog." />
        <meta property="og:image" content="https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=800" />
      </Helmet>
      <div className="w-full max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white">Blog & Updates</h1>
          <p className="mt-4 text-lg text-gray-300">The latest articles, guides, and news from our team.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, index) => (
            <motion.div
              key={post.slug}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="bg-gray-800 border-gray-700 h-full flex flex-col overflow-hidden group">
                <Link to={`/blog/${post.slug}`} className="block overflow-hidden">
                  <img  alt={post.title} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" src="https://images.unsplash.com/photo-1621165031056-2fb2961935d1" />
                </Link>
                <CardContent className="p-6 flex flex-col flex-grow">
                  <div className="flex-grow">
                    <div className="flex flex-wrap gap-2 mb-4">
                      {post.tags.map(tag => (
                        <Badge key={tag} variant="secondary" className="bg-red-500/10 text-red-400 border-none">{tag}</Badge>
                      ))}
                    </div>
                    <h2 className="text-xl font-bold text-white mb-3 group-hover:text-red-500 transition-colors">
                      <Link to={`/blog/${post.slug}`}>{post.title}</Link>
                    </h2>
                    <p className="text-gray-400 mb-6 text-sm">{post.excerpt}</p>
                  </div>
                  <Button asChild variant="outline" className="mt-auto border-gray-600 hover:bg-red-600 hover:text-white hover:border-red-600 w-full">
                    <Link to={`/blog/${post.slug}`}>Read More</Link>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Blog;