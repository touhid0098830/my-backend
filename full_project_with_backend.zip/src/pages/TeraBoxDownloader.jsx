import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Box } from 'lucide-react';
import VideoDownloader from '@/components/VideoDownloader';

const TeraBoxDownloader = () => {
  const toolConfig = {
    placeholder: 'Paste Terabox/Mdisk/Pdisk link here',
    supportedDomains: ['terabox', 'mdisk', 'pdisk', '1024tera'],
    title: 'TeraBox/Mdisk/Pdisk',
  };

  return (
    <>
      <Helmet>
        <title>Watch & Download TeraBox, Mdisk, and Pdisk Videos Online</title>
        <meta name="description" content="Paste your TeraBox, Mdisk, or Pdisk link to play videos online or download them in multiple formats." />
        <meta property="og:title" content="Watch & Download TeraBox, Mdisk, and Pdisk Videos Online" />
        <meta property="og:description" content="Paste your TeraBox, Mdisk, or Pdisk link to play videos online or download them in multiple formats." />
        <meta property="og:image" content="https://images.unsplash.com/photo-1593508512255-86ab42a8e620?w=800" />
      </Helmet>
      <div className="w-full max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10"
        >
          <Box className="w-16 h-16 mx-auto text-red-500 mb-4" />
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white">Terabox, Mdisk, and Pdisk Video Downloader</h1>
          <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">
            Use this tool to watch or download videos from Terabox, Mdisk, or Pdisk. Just paste the link and start watching or saving!
          </p>
        </motion.div>

        <VideoDownloader toolConfig={toolConfig} />
      </div>
    </>
  );
};

export default TeraBoxDownloader;