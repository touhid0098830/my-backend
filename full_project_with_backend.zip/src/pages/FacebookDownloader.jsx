import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Facebook } from 'lucide-react';
import VideoDownloader from '@/components/VideoDownloader';

const FacebookDownloader = () => {
  const toolConfig = {
    placeholder: 'Paste Facebook video URL',
    supportedDomains: ['facebook.com', 'fb.watch'],
    title: 'Facebook',
  };

  return (
    <>
      <Helmet>
        <title>Facebook Video Downloader - Save FB Videos in One Click</title>
        <meta name="description" content="Fast and free Facebook video downloader. Save private or public videos from Facebook to your device in MP4 or MP3 format." />
        <meta property="og:title" content="Facebook Video Downloader - Save FB Videos in One Click" />
        <meta property="og:description" content="Fast and free Facebook video downloader. Save private or public videos from Facebook to your device." />
        <meta property="og:image" content="https://images.unsplash.com/photo-1611262588024-d12430b98920?w=800" />
      </Helmet>
      <div className="w-full max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10"
        >
          <Facebook className="w-16 h-16 mx-auto text-red-500 mb-4" />
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white">Facebook Video Downloader</h1>
          <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">
            Paste any Facebook video link and instantly get download options. No watermark, no app install required.
          </p>
        </motion.div>

        <VideoDownloader toolConfig={toolConfig} />
      </div>
    </>
  );
};

export default FacebookDownloader;