import React from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calendar, Tag, ArrowLeft } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import blogPosts from '@/data/blogPosts.json';

const BlogPost = () => {
  const { slug } = useParams();
  const post = blogPosts.find((p) => p.slug === slug);

  if (!post) {
    return <Navigate to="/404" />;
  }

  return (
    <>
      <Helmet>
        <title>{post.metaTitle}</title>
        <meta name="description" content={post.metaDescription} />
        <meta property="og:title" content={post.metaTitle} />
        <meta property="og:description" content={post.metaDescription} />
        <meta property="og:image" content={post.image} />
        <meta property="og:type" content="article" />
      </Helmet>
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="mb-8">
            <Button asChild variant="ghost" className="text-red-400 hover:text-red-500 hover:bg-gray-800">
              <Link to="/blog">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Blog
              </Link>
            </Button>
          </div>

          <article className="prose prose-invert prose-lg max-w-none bg-gray-800/50 rounded-xl p-6 md:p-10 border border-gray-700">
            <div className="mb-8">
              <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4">{post.title}</h1>
              <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-gray-400">
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  <span>{post.date}</span>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <Tag className="h-5 w-5" />
                  {post.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="bg-red-500/10 text-red-400 border-none">{tag}</Badge>
                  ))}
                </div>
              </div>
            </div>
            
            <img  alt={post.title} className="w-full rounded-lg mb-8 aspect-video object-cover" src="https://images.unsplash.com/photo-1621165031056-2fb2961935d1" />

            <div
              className="text-gray-300"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
          </article>
        </motion.div>
      </div>
    </>
  );
};

export default BlogPost;