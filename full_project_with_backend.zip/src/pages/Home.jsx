import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Youtube, Facebook, Box } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Home = () => {
  const tools = [
    {
      name: 'YouTube Downloader',
      icon: Youtube,
      path: '/youtube-downloader',
      description: 'Download YouTube videos in HD quality.',
      anchorText: 'Download YouTube Videos',
    },
    {
      name: 'Facebook Downloader',
      icon: Facebook,
      path: '/facebook-downloader',
      description: 'Save private or public videos from Facebook.',
      anchorText: 'Download Facebook Videos',
    },
    {
      name: 'TeraBox Downloader',
      icon: Box,
      path: '/terabox-downloader',
      description: 'Watch & download from TeraBox, Mdisk, Pdisk.',
      anchorText: 'Watch & Download Terabox Videos',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Free Video Downloader | Save from YouTube, Facebook, Terabox</title>
        <meta name="description" content="Download videos from YouTube, Facebook, Terabox, Mdisk & more. Convert videos to MP4, MP3 in HD quality without installing anything." />
        <meta property="og:title" content="Free Video Downloader | Save from YouTube, Facebook, Terabox" />
        <meta property="og:description" content="Download videos from YouTube, Facebook, Terabox, Mdisk & more. Convert videos to MP4, MP3 in HD quality without installing anything." />
        <meta property="og:image" content="https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800" />
      </Helmet>
      <div className="text-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white leading-tight">
            Free Online Video Downloader for <span className="text-red-500">YouTube, Facebook, TeraBox</span>
          </h1>
          <p className="mt-6 max-w-3xl mx-auto text-lg md:text-xl text-gray-300">
            Download videos online from YouTube, Facebook, Terabox, Mdisk, and Pdisk. Use our free video downloader tools to save videos in MP4, MP3, HD, and more — no software required.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8"
        >
          {tools.map((tool, index) => {
            const Icon = tool.icon;
            return (
              <div key={index} className="bg-gray-800 p-8 rounded-xl border border-gray-700 hover:border-red-500 transition-all duration-300 transform hover:-translate-y-2 flex flex-col">
                <Icon className="w-16 h-16 mx-auto text-red-500 mb-6" />
                <h2 className="text-2xl font-bold text-white mb-3">{tool.name}</h2>
                <p className="text-gray-400 mb-6 flex-grow">{tool.description}</p>
                <Button asChild size="lg" className="bg-red-600 hover:bg-red-700 w-full mt-auto">
                  <Link to={tool.path}>{tool.anchorText}</Link>
                </Button>
              </div>
            );
          })}
        </motion.div>
      </div>
    </>
  );
};

export default Home;