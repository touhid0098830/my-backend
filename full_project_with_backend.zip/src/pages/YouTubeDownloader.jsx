import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Youtube } from 'lucide-react';
import VideoDownloader from '@/components/VideoDownloader';

const YouTubeDownloader = () => {
  const toolConfig = {
    placeholder: 'Paste YouTube link here',
    supportedDomains: ['youtube.com', 'youtu.be'],
    title: 'YouTube',
  };

  return (
    <>
      <Helmet>
        <title>YouTube Video Downloader - Convert & Save Videos in MP4 or MP3</title>
        <meta name="description" content="Download YouTube videos in HD quality. Convert to MP4 or MP3 with our free YouTube Video Downloader tool. No ads, no login." />
        <meta property="og:title" content="YouTube Video Downloader - Convert & Save Videos in MP4 or MP3" />
        <meta property="og:description" content="Download YouTube videos in HD quality. Convert to MP4 or MP3 with our free YouTube Video Downloader tool." />
        <meta property="og:image" content="https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=800" />
      </Helmet>
      <div className="w-full max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10"
        >
          <Youtube className="w-16 h-16 mx-auto text-red-500 mb-4" />
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white">YouTube Video Downloader</h1>
          <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">
            Paste any YouTube link below to download the video instantly. You can also convert the video to MP3 or choose different video resolutions.
          </p>
        </motion.div>
        
        <VideoDownloader toolConfig={toolConfig} />
      </div>
    </>
  );
};

export default YouTubeDownloader;