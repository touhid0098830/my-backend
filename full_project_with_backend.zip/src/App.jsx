import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import Blog from '@/pages/Blog';
import BlogPost from '@/pages/BlogPost';
import YouTubeDownloader from '@/pages/YouTubeDownloader';
import FacebookDownloader from '@/pages/FacebookDownloader';
import TeraBoxDownloader from '@/pages/TeraBoxDownloader';
import { Toaster } from '@/components/ui/toaster';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogPost />} />
          <Route path="/youtube-downloader" element={<YouTubeDownloader />} />
          <Route path="/facebook-downloader" element={<FacebookDownloader />} />
          <Route path="/terabox-downloader" element={<TeraBoxDownloader />} />
        </Routes>
      </Layout>
      <Toaster />
    </Router>
  );
}

export default App;